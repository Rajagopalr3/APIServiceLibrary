package com.invenzolabs.apiservice;

import android.app.Dialog;
import android.util.Log;

import com.invenzolabs.apiservice.http.AuthFailureError;
import com.invenzolabs.apiservice.http.NetworkError;
import com.invenzolabs.apiservice.http.ParseError;
import com.invenzolabs.apiservice.http.Response;
import com.invenzolabs.apiservice.http.ServerError;
import com.invenzolabs.apiservice.http.TimeoutError;
import com.invenzolabs.apiservice.http.VolleyError;


public class ErrorListener implements Response.ErrorListener {

    private ActivityResponseListener activityReference;
    private String requestTag;
    private Dialog dialog = null;

    ErrorListener(ActivityResponseListener context, String tag, Dialog pd) {
        this.activityReference = context;
        this.requestTag = tag;
        this.dialog = pd;
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        if (activityReference != null) {
            String errorMessage = "";
            if (error instanceof NetworkError) {
                errorMessage += "Network Connection Error ";
            } else if (error instanceof ServerError) {
                errorMessage += "Server connection Error ";
            } else if (error instanceof AuthFailureError) {
                errorMessage += "AuthFailureError ";
            } else if (error instanceof ParseError) {
                errorMessage += "ParseError ";
            } else if (error instanceof TimeoutError) {
                errorMessage += "Request Timeout";
            }
            Log.e(requestTag, errorMessage);
            activityReference.onError(errorMessage, requestTag);
        }
        if (dialog != null && dialog.isShowing())
            dialog.dismiss();

    }


}
