package com.libRG;

public interface ActivityResponseListener {

	public <T> void onResponse(T response, String tagName);
	public void onError(Object error, String tagName);
	
}
